# Spring Integration Example
This is an example Spring Integration inside a Spring Boot app using Spring Integration File

## Versions Used
- Spring Boot - 2.0.5
- Spring Boot Starter Integration - 2.0.5
- Spring Integration File - 5.0.8
- Java - 8

## How to run?
- Run the main class `SpringIntegrationExample1Application.java`
- The source file is under `source` directory.
- The transformed files will be under `destination` directory.

